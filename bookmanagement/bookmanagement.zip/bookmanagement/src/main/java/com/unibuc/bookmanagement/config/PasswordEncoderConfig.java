package com.unibuc.bookmanagement.config;

public class PasswordEncoderConfig {

}
